const board = document.querySelector(".board");
const rollButton = document.getElementById("rollButton");
const message = document.getElementById("message");

// Setup Snake and Ladder positions
const snakes = {
  16: 6,
  47: 26,
  49: 11,
  56: 53,
  62: 19,
  64: 60,
  87: 24,
  93: 73,
  95: 75,
  98: 78,
};

const ladders = {
  1: 38,
  4: 14,
  9: 31,
  21: 42,
  28: 84,
  36: 44,
  51: 67,
  71: 91,
  80: 100,
};

let playerPosition = 1;

function setupBoard() {
  for (let i = 1; i <= 100; i++) {
    const cell = document.createElement("div");
    cell.classList.add("cell");
    cell.id = `cell-${i}`;
    cell.textContent = i;
    board.appendChild(cell);
  }
}

function rollDice() {
  return Math.floor(Math.random() * 6) + 1;
}

function movePlayer(steps) {
  playerPosition += steps;

  if (playerPosition > 100) {
    playerPosition = 100;
  }

  // Check for snake or ladder
  if (snakes[playerPosition]) {
    playerPosition = snakes[playerPosition];
    message.textContent = "Oops! A snake! You went down.";
  } else if (ladders[playerPosition]) {
    playerPosition = ladders[playerPosition];
    message.textContent = "Yay! A ladder! You went up.";
  }

  document.querySelector(`#cell-${playerPosition}`).textContent = "🚶‍♂️";
  message.textContent += ` Your current position: ${playerPosition}`;
}

rollButton.addEventListener("click", () => {
  const diceRoll = rollDice();
  message.textContent = `You rolled a ${diceRoll}`;
  movePlayer(diceRoll);
});

setupBoard();
